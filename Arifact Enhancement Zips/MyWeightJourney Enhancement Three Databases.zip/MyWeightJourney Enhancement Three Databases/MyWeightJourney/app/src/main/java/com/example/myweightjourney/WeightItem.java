// Darrell Chism
// phantomcodingllc@gmail.com
// 09/23/23
// Version 1.3
// Weight logging app for Android




package com.example.myweightjourney;

public class WeightItem {
    // Declare private fields to store date and weight
    private String date;
    private double weight;

    // Constructor to initialize date and weight when creating a WeightItem
    public WeightItem(String date, double weight) {
        this.date = date;
        this.weight = weight;
    }

    // Getter method to retrieve the data of the WeightItem
    public String getDate() {
        return date;
    }


    // Getter method to retrieve the weight of the WeightItem
    public double getWeight() {
        return weight;
    }
}
