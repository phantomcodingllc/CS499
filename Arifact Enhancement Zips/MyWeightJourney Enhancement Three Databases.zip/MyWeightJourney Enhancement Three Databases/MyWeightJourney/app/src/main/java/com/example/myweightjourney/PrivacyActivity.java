// Darrell Chism
// phantomcodingllc@gmail.com
// 09/23/23
// Version 1.3
// Weight logging app for Android


package com.example.myweightjourney;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

public class PrivacyActivity extends AppCompatActivity {

    //UI elements
    private CheckBox agreeCheckBox;
    private Button backButton;
    private boolean smsPermissionGranted = false;

    //Constants
    private static final String TAG = PrivacyActivity.class.getSimpleName();
    private static final int PERMISSION_REQUEST_SEND_SMS = 123;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_privacy);

        //Initialize UI elements
        agreeCheckBox = findViewById(R.id.agree_checkbox);
        backButton = findViewById(R.id.back_button);

        // Set OnClickListener for the Agree checkbox
        agreeCheckBox.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onAgreeCheckBoxClicked();
            }
        });

        // Set OnClickListener for the Back button
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        // Check SMS permission and request if necessary
        if (checkSelfPermission(Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.SEND_SMS}, PERMISSION_REQUEST_SEND_SMS);
        } else {
            smsPermissionGranted = true;
        }

        final EditText phoneNumberEditText = findViewById(R.id.phone_input);
        final Button saveButton = findViewById(R.id.save_button);

        //Set OnClickListener for Save button
        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String phoneNumber = phoneNumberEditText.getText().toString();

                if (!phoneNumber.isEmpty()) {
                    DatabaseHelper databaseHelper = new DatabaseHelper(PrivacyActivity.this);
                    boolean success = databaseHelper.savePhoneNumber(phoneNumber);

                    if (success) {
                        Toast.makeText(PrivacyActivity.this, "Phone number saved.", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(PrivacyActivity.this, "Failed to save phone number.", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(PrivacyActivity.this, "Please enter a phone number.", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    // Handle the Agree checkbox click event
    private void onAgreeCheckBoxClicked() {
        if (agreeCheckBox.isChecked()) {
            backButton.setEnabled(true);
        } else {
            backButton.setEnabled(false);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case PERMISSION_REQUEST_SEND_SMS:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    // Permission granted, enable SMS feature
                    smsPermissionGranted = true;
                } else {
                    // Permission denied, disable SMS feature
                    smsPermissionGranted = false;
                    Toast.makeText(this, "SMS permission denied", Toast.LENGTH_SHORT).show();
                }
                break;
            default:
                Log.d(TAG, "Unhandled permission request code: " + requestCode);
        }
    }

    // Send SMS notification with given message body
    private void sendSmsNotification(String message) {
        String phoneNumber = new DatabaseHelper(this).getUserPhoneNumber();
        if (smsPermissionGranted && phoneNumber != null) {
            try {
                SmsManager smsManager = SmsManager.getDefault();
                smsManager.sendTextMessage(phoneNumber, null, message, null, null);
                Toast.makeText(this, "SMS notification sent", Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Toast.makeText(this, "Failed to send SMS notification", Toast.LENGTH_SHORT).show();
                Log.e(TAG, "Failed to send SMS notification", e);
            }
        }
    }

    @Override
    public void onBackPressed() {
        if (agreeCheckBox.isChecked()) {
            // Retrieve user's last logged weight from the database
            DatabaseHelper db = new DatabaseHelper(this);
            double currentWeight = db.getLastLoggedWeight();

            // Retrieve user's goal weight from the database
            double goalWeight = db.getGoalWeight();

            // Send SMS notification with weight and goal information
            String message = "Your weight is reaching your goal! Your current weight is: " +
                    currentWeight + " and your goal weight is: " + goalWeight +
                    ". Keep up the great work!";
            sendSmsNotification(message);
        }
        Intent intent = new Intent(this, WeightTrackingActivity.class);
        startActivity(intent);
        finish();
    }

}