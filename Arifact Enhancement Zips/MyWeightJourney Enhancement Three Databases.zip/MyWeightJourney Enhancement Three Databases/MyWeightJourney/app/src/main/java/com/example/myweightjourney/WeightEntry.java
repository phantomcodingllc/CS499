// Darrell Chism
// phantomcodingllc@gmail.com
// 09/23/23
// Version 1.3
// Weight logging app for Android




package com.example.myweightjourney;

public class WeightEntry {
    //Variables to store data, weight, and ID
    private String mDate;
    private double mWeight;
    private int mId;

    //Constructor for creating new WeightEntry with date and weight
    public WeightEntry(String date, double weight) {
        mDate = date;
        mWeight = weight;
        mId = -1;
    }

    //Constructor for creating WeightEntry with all properties.
    public WeightEntry(double weight, String date, int id) {
        mWeight = weight;
        mDate = date;
        mId = id;
    }

    // getters and setters

    //Get date
    public String getDate() {
        return mDate;
    }

    //Set date
    public void setDate(String date) {
        mDate = date;
    }

    //Get weight
    public double getWeight() {
        return mWeight;
    }

    //Set weight
    public void setWeight(double weight) {
        mWeight = weight;
    }

    //Get ID
    public int getId() {
        return mId;
    }

    //Set ID
    public void setId(int id) {
        mId = id;
    }

    // Override toString to return date, weight
    @Override
    public String toString() {
        return "Date: " + mDate + ", " + mWeight + " lbs.";
    }
}
