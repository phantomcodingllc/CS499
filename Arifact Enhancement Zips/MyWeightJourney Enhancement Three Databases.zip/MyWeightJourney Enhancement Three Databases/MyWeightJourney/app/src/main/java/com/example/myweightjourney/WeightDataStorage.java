// Darrell Chism
// phantomcodingllc@gmail.com
// 09/23/23
// Version 1.3
// Weight logging app for Android



package com.example.myweightjourney;

import android.content.Context;
import android.content.SharedPreferences;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.util.ArrayList;
import java.util.List;

public class WeightDataStorage {

    // Define the shared preferences file name and key
    private static final String PREF_NAME = "WeightDataPrefs";
    private static final String KEY_WEIGHT_DATA = "weight_data";

    // Declare SharedPreferences and Gson objects
    private SharedPreferences sharedPreferences;
    private Gson gson;

    // Constructor to initialize the SharedPreferences and Gson objects
    public WeightDataStorage(Context context) {
        // Initialize SharedPreferences with the specified file name and mode
        sharedPreferences = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        gson = new Gson();
    }

    // Method to save a list of WeightItem objects to SharedPreferences
    public void saveWeightList(List<WeightItem> weightItemList) {
        // Get an editor for modifying SharedPreferences
        SharedPreferences.Editor editor = sharedPreferences.edit();

        // Convert the list of WeightItem objects to JSON format
        String json = gson.toJson(weightItemList);

        // Store the JSON data in SharedPreferences under the specified key
        editor.putString(KEY_WEIGHT_DATA, json);

        // Apply the changes to SharedPreferences
        editor.apply();
    }

    // Method to retrieve a list of WeightItem objects from SharedPreferences
    public List<WeightItem> getWeightList() {
        // Retrieve the JSON data from SharedPreferences using the specified key
        String json = sharedPreferences.getString(KEY_WEIGHT_DATA, "");

        // Initialize an empty list as a fallback
        List<WeightItem> weightItemList = new ArrayList<>();

        // Convert the JSON data back to a list of WeightItem objects
        try {
            weightItemList = gson.fromJson(json, new TypeToken<List<WeightItem>>(){}.getType());
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Return the list of WeightItem objects
        return weightItemList;
    }
}
