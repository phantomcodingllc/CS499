// Darrell Chism
// phantomcodingllc@gmail.com
// 09/23/23
// Version 1.3
// Weight logging app for Android



package com.example.myweightjourney;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    // Define UI elements
    private EditText mUsernameEditText;
    private EditText mPasswordEditText;
    private Button mLoginButton;
    private Button mRegisterButton;
    private DatabaseHelper mDBHelper;
   // private EditText phoneNumberEditText;
 //   private Button saveButton;

    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Initialize UI elements
        mUsernameEditText = findViewById(R.id.username_edit_text);
        mPasswordEditText = findViewById(R.id.password_edit_text);
        mLoginButton = findViewById(R.id.login_button);
        mRegisterButton = findViewById(R.id.register_button);
        mDBHelper = new DatabaseHelper(this);
        //phoneNumberEditText = findViewById(R.id.phone_input);
       // saveButton = findViewById(R.id.save_button);

        //Create new instance of database helper
        databaseHelper = new DatabaseHelper(this);

        //When login button clicked, execute logic
        mLoginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = mUsernameEditText.getText().toString();
                String password = mPasswordEditText.getText().toString();

                if (username.isEmpty() || password.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Please enter both username and password.", Toast.LENGTH_SHORT).show();
                } else {
                    // Perform login logic here
                    boolean success = mDBHelper.loginUser(username, password);

                    if (success) {
                        // Start the WeightTrackingActivity
                        Intent intent = new Intent(MainActivity.this, WeightTrackingActivity.class);
                        startActivity(intent);
                    } else {
                        Toast.makeText(MainActivity.this, "Incorrect username or password.", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        mRegisterButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Insert new user into database
                String username = mUsernameEditText.getText().toString();
                String password = mPasswordEditText.getText().toString();

                if (username.isEmpty() || password.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Please enter both username and password.", Toast.LENGTH_SHORT).show();
                } else {
                    boolean success = mDBHelper.registerUser(username, password);

                    if (success) {
                        Toast.makeText(MainActivity.this, "Registration successful.", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(MainActivity.this, "Username already exists.", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

    }


    public void onLoginClick(View view) {
        // Handle login button click
        mLoginButton.performClick();
    }

    public void onRegisterClick(View view) {
        // Handle register button click
        mRegisterButton.performClick();
    }
}
