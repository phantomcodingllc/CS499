// Darrell Chism
// phantomcodingllc@gmail.com
// 09/23/23
// Version 1.3
// Weight logging app for Android


package com.example.myweightjourney;

import androidx.appcompat.app.AppCompatActivity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.Toast;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class WeightTrackingActivity extends AppCompatActivity {

    private CalendarView calendarView;
    private RecyclerView recyclerView;
    private WeightListAdapter adapter;
    private List<WeightItem> weightItemList;
    private WeightDataStorage dataStorage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weight_tracking);

        calendarView = findViewById(R.id.calendar_view);
        recyclerView = findViewById(R.id.recycler_view);
        dataStorage = new WeightDataStorage(this);

        weightItemList = dataStorage.getWeightList();
        if (weightItemList == null) {
            weightItemList = new ArrayList<>();
        }

        // Initialize the RecyclerView with reverseLayout set to true
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        layoutManager.setReverseLayout(true);
        recyclerView.setLayoutManager(layoutManager);

        adapter = new WeightListAdapter(weightItemList);
        recyclerView.setAdapter(adapter);

        calendarView.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(CalendarView view, int year, int month, int dayOfMonth) {
                String selectedDate = year + "-" + (month + 1) + "-" + dayOfMonth;
                showWeightInputDialog(selectedDate);
            }
        });
    }

    private void showWeightInputDialog(final String selectedDate) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.dialog_weight_input, null);
        builder.setView(dialogView);

        final EditText weightInput = dialogView.findViewById(R.id.weight_input);

        builder.setPositiveButton("Submit", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String weightStr = weightInput.getText().toString().trim();
                if (!weightStr.isEmpty()) {
                    double weight = Double.parseDouble(weightStr);

                    WeightItem weightItem = new WeightItem(selectedDate, weight);
                    weightItemList.add(weightItem);
                    adapter.notifyDataSetChanged();

                    // Save the updated weight list to storage
                    dataStorage.saveWeightList(weightItemList);

                    String message = "Weight: " + weight + " lbs\nDate: " + selectedDate;
                    Toast.makeText(WeightTrackingActivity.this, message, Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(WeightTrackingActivity.this, "Please enter weight.", Toast.LENGTH_SHORT).show();
                }
            }
        });

        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });

        builder.show();
    }
}
