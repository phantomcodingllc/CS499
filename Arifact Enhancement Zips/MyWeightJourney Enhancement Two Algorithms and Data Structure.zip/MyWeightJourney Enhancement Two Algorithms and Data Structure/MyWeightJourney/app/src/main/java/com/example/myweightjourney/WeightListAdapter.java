// Darrell Chism
// phantomcodingllc@gmail.com
// 09/23/23
// Version 1.3
// Weight logging app for Android




package com.example.myweightjourney;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class WeightListAdapter extends RecyclerView.Adapter<WeightListAdapter.ViewHolder> {
    private List<WeightItem> weightItemList;

    public WeightListAdapter(List<WeightItem> weightItemList) {
        this.weightItemList = weightItemList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        Context context = parent.getContext();
        LayoutInflater inflater = LayoutInflater.from(context);

        // Inflate the custom layout
        View weightView = inflater.inflate(R.layout.custom_weight_list_item, parent, false);

        // Return a new ViewHolder
        return new ViewHolder(weightView);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        // Get the data model based on position
        WeightItem weightItem = weightItemList.get(position);

        // Set the date and weight values
        holder.dateTextView.setText(weightItem.getDate());
        holder.weightTextView.setText(weightItem.getWeight() + " lbs");
    }

    @Override
    public int getItemCount() {
        return weightItemList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public TextView dateTextView;
        public TextView weightTextView;

        public ViewHolder(View itemView) {
            super(itemView);

            // Find views within the item layout
            dateTextView = itemView.findViewById(R.id.dateTextView);
            weightTextView = itemView.findViewById(R.id.weightTextView);
        }
    }
}
