// Darrell Chism
// phantomcodingllc@gmail.com
// 09/23/23
// Version 1.3
// Weight logging app for Android




package com.example.myweightjourney;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.Date;

import java.util.ArrayList;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "weight.db";
    private static final int DATABASE_VERSION = 2;
    // Table and column names
    public static final String TABLE_WEIGHT = "weight";
    public static final String COLUMN_ID = "_id";
    public static final String COLUMN_WEIGHT = "weight";
    public static final String COLUMN_DATE = "date";
    // Table and column names for the users table
    public static final String TABLE_USERS = "users";
    public static final String COLUMN_USERNAME = "username";
    public static final String COLUMN_PASSWORD = "password";
    // Table and column names for the user info table
    public static final String TABLE_USER_INFO = "user_info";
    public static final String COLUMN_PHONE_NUMBER = "phone_number";
    private static final String COLUMN_GOAL_WEIGHT = "goal_weight";

    // SQL statement to create the weight table
    private static final String CREATE_WEIGHT_TABLE = "CREATE TABLE " + TABLE_WEIGHT + " (" +
            COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
            COLUMN_WEIGHT + " REAL NOT NULL, " +
            COLUMN_DATE + " TEXT NOT NULL, " +
            COLUMN_GOAL_WEIGHT + " REAL" +
            ");";
    // SQL statement to create the users table
    private static final String CREATE_USERS_TABLE = "CREATE TABLE " + TABLE_USERS + " (" +
            COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
            COLUMN_USERNAME + " TEXT NOT NULL, " +
            COLUMN_PASSWORD + " TEXT NOT NULL" + ");";

    private static final String CREATE_USER_INFO_TABLE = "CREATE TABLE " + TABLE_USER_INFO + " ( " +
            COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " + COLUMN_PHONE_NUMBER + " TEXT)";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create the weight, users, and user_info tables if they don't exist already
        db.execSQL("CREATE TABLE IF NOT EXISTS " + TABLE_WEIGHT + " (" +
                COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_WEIGHT + " REAL NOT NULL, " +
                COLUMN_DATE + " TEXT NOT NULL, " +
                COLUMN_GOAL_WEIGHT + " REAL" +
                ");");
        db.execSQL("CREATE TABLE IF NOT EXISTS " + TABLE_USERS + " (" +
                COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_USERNAME + " TEXT NOT NULL, " +
                COLUMN_PASSWORD + " TEXT NOT NULL" +
                ");");
        db.execSQL("CREATE TABLE IF NOT EXISTS " + TABLE_USER_INFO + " ( " +
                COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_PHONE_NUMBER + " TEXT" +
                ");");
    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // If the old version is less than 2, drop the tables and recreate them
        if (oldVersion < 2) {
            db.execSQL("DROP TABLE IF EXISTS " + TABLE_WEIGHT);
            db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
            onCreate(db);
        } else {
            // Create a temporary table with the new schema
            db.execSQL("CREATE TABLE temp_users (" +
                    COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COLUMN_USERNAME + " TEXT NOT NULL, " +
                    COLUMN_PASSWORD + " TEXT NOT NULL" + ");");

            // Copy the data from the old table to the new table
            db.execSQL("INSERT INTO temp_users(" +
                    COLUMN_ID + ", " +
                    COLUMN_USERNAME + ", " +
                    COLUMN_PASSWORD + ") " +
                    "SELECT " +
                    COLUMN_ID + ", " +
                    COLUMN_USERNAME + ", " +
                    COLUMN_PASSWORD + " " +
                    "FROM " + TABLE_USERS);

            // Drop the old table
            db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);

            // Rename the temporary table to the original name
            db.execSQL("ALTER TABLE temp_users RENAME TO " + TABLE_USERS);
        }
    }
    public ArrayList<WeightEntry> getAllWeightEntries() {
        ArrayList<WeightEntry> weightEntries = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.query(TABLE_WEIGHT, null, null, null, null, null, null);

        int idIndex = cursor.getColumnIndex(COLUMN_ID);
        int weightIndex = cursor.getColumnIndex(COLUMN_WEIGHT);
        int dateIndex = cursor.getColumnIndex(COLUMN_DATE);

        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(idIndex);
                double weight = cursor.getDouble(weightIndex);
                String date = cursor.getString(dateIndex);
                if (id >= 0) {
                    weightEntries.add(new WeightEntry(weight, date, id));
                }
            } while (cursor.moveToNext());
        }

        cursor.close();
        return weightEntries;
    }
    //Add weight entry to database
    public void addWeightEntry(WeightEntry weightEntry) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_WEIGHT, weightEntry.getWeight());
        values.put(COLUMN_DATE, weightEntry.getDate());
        if (weightEntry.getId() >= 0) {
            values.put(COLUMN_ID, weightEntry.getId());
        }
        db.insert(TABLE_WEIGHT, null, values);
        db.close();
    }
    //Delete weight entry from database
    public void deleteWeightEntry(WeightEntry weightEntry) {
        SQLiteDatabase db = getWritableDatabase();
        int id = weightEntry.getId();
        if (id >= 0) {
            db.delete(TABLE_WEIGHT, COLUMN_ID + "=?", new String[]{String.valueOf(id)});
        }
        db.close();
    }
    //Update weight entry in database
    public void updateWeightEntry(int id, WeightEntry weightEntry) {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COLUMN_WEIGHT, weightEntry.getWeight());
        values.put(COLUMN_DATE, weightEntry.getDate());

        db.update(TABLE_WEIGHT, values, COLUMN_ID + "=?", new String[]{String.valueOf(id)});
        db.close();
    }
    //Attempt to log user in by checking credentials
    public boolean loginUser(String username, String password) {
        SQLiteDatabase db = getReadableDatabase();
        String[] projection = {};

        //Construct SQL selection clause to match provided username and password
        String selection = COLUMN_USERNAME + " = ? AND " + COLUMN_PASSWORD + " = ?";
        String[] selectionArgs = {username, password};

        //Execute query on users table to check for matching user
        Cursor cursor = db.query(
                TABLE_USERS,
                projection,
                selection,
                selectionArgs,
                null,
                null,
                null
        );

        boolean success = false;

        //Check if query returned any matching rows
        if (cursor.getCount() > 0) {
            success = true;
        }

        cursor.close();
        db.close();

        return success;
    }
    //Register new user's username and password into database
    public boolean registerUser(String username, String password) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_USERNAME, username);
        values.put(COLUMN_PASSWORD, password);

        boolean success = true;

        try {
            //Attempt to insert user's data
            db.insertOrThrow(TABLE_USERS, null, values);
        } catch (Exception e) {
            //If error occurred, fail
            success = false;
        }

        db.close();

        return success;
    }
    //Save user's phone number
    public void saveUserPhoneNumber(String phoneNumber) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("phone_number", phoneNumber);
        db.insert("user_info", null, values);
        db.close();
    }
    //Save user's phone number entry into database
    public boolean savePhoneNumber(String phoneNumber) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("phone_number", phoneNumber);
        long result = db.insert("user_info", null, values);
        db.close();
        return result != -1;
    }
    //Query user database for user phone number
    public String getUserPhoneNumber() {
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT phone_number FROM user_info", null);

        String phoneNumber = null;
        if (cursor.moveToFirst()) {
            phoneNumber = cursor.getString(0);
        }

        cursor.close();
        db.close();

        return phoneNumber;
    }
    //Save user's weight entry into database as new entry
    public boolean saveGoalWeight(double goalWeight) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_WEIGHT, 0); // set default weight value
        values.put(COLUMN_DATE, new Date().toString()); // set current date
        values.put(COLUMN_GOAL_WEIGHT, goalWeight);
        long result = db.insert(TABLE_WEIGHT, null, values);
        db.close();
        return result != -1;
    }
    //Retrieve user's last weight entry in database
    public double getLastLoggedWeight() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_WEIGHT, new String[]{COLUMN_WEIGHT}, null, null, null, null, COLUMN_DATE + " DESC", "1");
        double lastLoggedWeight = -1;

        if (cursor != null) {
            if (cursor.moveToFirst()) {
                int weightIndex = cursor.getColumnIndex(COLUMN_WEIGHT);

                if (weightIndex != -1) {
                    lastLoggedWeight = cursor.getDouble(weightIndex);
                }
            }

            cursor.close();
        }

        return lastLoggedWeight >= 0 ? lastLoggedWeight : 0;
    }
    //Retrieve user's goal weight they entered
    public double getGoalWeight() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_USER_INFO, new String[]{COLUMN_GOAL_WEIGHT}, null, null, null, null, null);

        double goalWeight = -1;

        if (cursor.moveToFirst()) {
            int goalWeightIndex = cursor.getColumnIndex(COLUMN_GOAL_WEIGHT);

            if (goalWeightIndex != -1) {
                goalWeight = cursor.getDouble(goalWeightIndex);
            }
        }

        cursor.close();
        return goalWeight;
    }
}
